"""Local Telegram Atlas server. Serves dist only; credentials never enter the browser."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
import argparse
import hashlib
import json
import os
import re
import threading

ROOT = Path(__file__).resolve().parent
CACHE = {}
LOCK = threading.Lock()

def api_key():
    value = os.environ.get('GOOGLE_CLOUD_TRANSLATION_API_KEY', '').strip()
    if value:
        return value
    path = ROOT / '.env'
    if path.exists():
        for line in path.read_text().splitlines():
            if line.strip().startswith('GOOGLE_CLOUD_TRANSLATION_API_KEY='):
                return line.split('=', 1)[1].strip().strip('\"\'')
    return ''

def translate_messages(messages, key):
    """Only original message text is sent. IDs and conversation metadata stay local."""
    result = {}
    with LOCK:
        pending = {}
        for message in messages:
            source = message['text']
            digest = hashlib.sha256(source.encode()).hexdigest()
            if digest not in CACHE:
                pending[digest] = source
        chunks = [(digest, source[i:i+4000]) for digest, source in pending.items()
                  for i in range(0, len(source), 4000)]
        assembled = {digest: [] for digest in pending}
        while chunks:
            batch, length = [], 0
            while chunks and len(batch) < 128 and length + len(chunks[0][1]) <= 20000:
                item = chunks.pop(0)
                batch.append(item)
                length += len(item[1])
            body = json.dumps({'q': [text for _, text in batch], 'target': 'en', 'format': 'text'}).encode()
            req = Request('https://translation.googleapis.com/language/translate/v2', data=body,
                          headers={'Content-Type': 'application/json', 'X-goog-api-key': key}, method='POST')
            with urlopen(req, timeout=45) as response:
                translations = json.load(response)['data']['translations']
            if len(translations) != len(batch):
                raise ValueError('Incomplete translation response')
            for (digest, _), translated in zip(batch, translations):
                text = translated['translatedText']
                if not isinstance(text, str):
                    raise ValueError('Invalid translation response')
                assembled[digest].append(text)
        for digest, texts in assembled.items():
            CACHE[digest] = ''.join(texts)
        for message in messages:
            digest = hashlib.sha256(message['text'].encode()).hexdigest()
            result[str(message['id'])] = CACHE[digest]
    return result

class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT / 'dist'), **kwargs)

    def json_response(self, status, payload):
        data = json.dumps(payload).encode()
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(data)

    def valid_host(self):
        return self.headers.get('Host') in {f'localhost:{self.server.server_port}', f'127.0.0.1:{self.server.server_port}'}

    def do_GET(self):
        if not self.valid_host():
            return self.json_response(403, {'error': 'Local access only.'})
        if urlsplit(self.path).path == '/api/translation-status':
            return self.json_response(200, {'configured': bool(api_key()), 'provider': 'Google Cloud Translation'})
        return super().do_GET()

    def do_POST(self):
        origin = self.headers.get('Origin')
        allowed = {f'http://localhost:{self.server.server_port}', f'http://127.0.0.1:{self.server.server_port}'}
        if not self.valid_host() or origin not in allowed:
            return self.json_response(403, {'error': 'Only requests from this app are accepted.'})
        if self.path != '/api/translate':
            return self.json_response(404, {'error': 'Unknown endpoint.'})
        if self.headers.get('Content-Type', '').split(';')[0] != 'application/json':
            return self.json_response(415, {'error': 'JSON required.'})
        try:
            size = int(self.headers.get('Content-Length', '0'))
            if not 0 < size <= 4096:
                raise ValueError()
            payload = json.loads(self.rfile.read(size))
            cid, ids = payload['conversation_id'], payload['message_ids']
            if not isinstance(cid, str) or not re.fullmatch(r'tgconv-[a-f0-9]{12}', cid):
                raise ValueError()
            if not isinstance(ids, list) or not 1 <= len(ids) <= 10 or any(type(i) is not int for i in ids):
                raise ValueError()
            path = ROOT / 'dist' / 'data' / (cid + '.json')
            if not path.is_file():
                return self.json_response(404, {'error': 'Conversation not found.'})
            doc = json.loads(path.read_text())
            by_id = {m['id']: m for m in doc['messages']}
            if any(i not in by_id or not by_id[i].get('text') for i in ids):
                raise ValueError()
            messages = [by_id[i] for i in ids]
        except (ValueError, KeyError, TypeError):
            return self.json_response(400, {'error': 'Select valid messages from one conversation.'})
        key = api_key()
        if not key:
            return self.json_response(503, {'error': 'Translation is not connected yet. Add the Google Cloud Translation key on the local server.'})
        try:
            translated = translate_messages(messages, key)
            return self.json_response(200, {'translations': translated, 'provider': 'Google Cloud Translation'})
        except HTTPError as error:
            if error.code == 429:
                message = 'Google’s translation quota is temporarily exhausted. Try again later.'
            elif error.code in (400, 401, 403):
                message = 'Google could not authorize translation. Check the key, billing and Cloud Translation API access.'
            else:
                message = 'Google Translation is temporarily unavailable. Please try again.'
            return self.json_response(502, {'error': message})
        except (URLError, TimeoutError, ValueError, KeyError, IndexError):
            return self.json_response(502, {'error': 'Translation could not complete. Please try again.'})

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, default=4173)
    args = parser.parse_args()
    print(f'Telegram Atlas: http://127.0.0.1:{args.port}', flush=True)
    ThreadingHTTPServer(('127.0.0.1', args.port), Handler).serve_forever()
